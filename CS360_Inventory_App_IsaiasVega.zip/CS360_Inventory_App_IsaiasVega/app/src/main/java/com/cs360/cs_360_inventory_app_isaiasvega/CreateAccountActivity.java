package com.cs360.cs_360_inventory_app_isaiasvega;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private EditText editConfirmPassword;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_create_account);

        //Connect UI components
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);
        Button backToLoginButton = findViewById(R.id.buttonBackToInventory);

        dbHelper = new DatabaseHelper(this);

        //Handle Create Account Button
        createAccountButton.setOnClickListener(v -> {
            try {
                createAccount();
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                throw new RuntimeException(e);
            }
        });

        //Handle Back to Login Button
        backToLoginButton.setOnClickListener(v -> finish());

    }

    private void createAccount() throws NoSuchAlgorithmException, InvalidKeySpecException {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();
        String confirmPassword = editConfirmPassword.getText().toString();

        //Validate fields
        if (username.isEmpty()){
            editUsername.setError("Enter your username.");
            return;
        }

        if (password.length() < 12){
            editPassword.setError("Password must be at least 12 characters long.");
            return;
        }

        if (!confirmPassword.equals(password)){
            editConfirmPassword.setError("Passwords do not match.");
            return;
        }

        //Attempts to register the user
        boolean success = dbHelper.registerUser(username, password);
        //If successfully added return to log in screen
        if (success){
            Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
            finish();
        }else{
            Toast.makeText(this, "Account Creation Failed", Toast.LENGTH_SHORT).show();
        }
    }
}
