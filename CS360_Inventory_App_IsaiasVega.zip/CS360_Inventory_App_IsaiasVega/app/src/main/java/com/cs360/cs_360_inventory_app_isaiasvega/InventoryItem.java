package com.cs360.cs_360_inventory_app_isaiasvega;

public class InventoryItem {
    private int itemId;
    private String itemName;
    private int quantity;
    private int minimum;

    public InventoryItem(int itemId, String itemName, int quantity, int minimum){
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.minimum = minimum;
    }

    //Getters and setters for item variables
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName(){
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        //Does not allow quantity below zero
        if(quantity < 0){
            throw new IllegalArgumentException("Quantity cannot be negative");
        }

        this.quantity = quantity;
    }

    public int getMinimum() {
        return minimum;
    }

    public void setMinimum(int minimum) {
        this.minimum = minimum;
    }

    //Helper methods
    public boolean isLowStock(){
        return quantity <= minimum;
    }
}
