package com.cs360.cs_360_inventory_app_isaiasvega;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {
    //List for inventory items
    private List<InventoryItem> items;
    private OnItemClickListener listener;

    public InventoryAdapter(List<InventoryItem> items, OnItemClickListener listener){
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        //Create a view with item inventory
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position){
        //Gets the inventory item
        InventoryItem item = items.get(position);

        //Shows the item information
        holder.itemName.setText(item.getItemName());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));
        holder.itemMinimum.setText(String.valueOf(item.getMinimum()));
        holder.editButton.setOnClickListener(v -> {listener.onEditClick(item);});
        holder.deleteButton.setOnClickListener(v -> {listener.onDeleteClick(item);});
    }

    @Override
    public int getItemCount(){
        return items.size();
    }

    public static class InventoryViewHolder extends RecyclerView.ViewHolder{
        TextView itemName;
        TextView itemQuantity;
        TextView itemMinimum;

        Button editButton;
        Button deleteButton;

        public InventoryViewHolder(@NonNull View itemView){
            super(itemView);

            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            itemMinimum = itemView.findViewById(R.id.itemMinimum);

            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }


    }

    public interface OnItemClickListener{
        void onEditClick(InventoryItem item);
        void onDeleteClick(InventoryItem item);
    }

    public void updateItems(List<InventoryItem> updatedItems){
        this.items = updatedItems;
        notifyDataSetChanged();
    }

}
