package com.cs360.cs_360_inventory_app_isaiasvega;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import android.util.Base64;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UserDatabase.db";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE users (" +
                    "user_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "username TEXT NOT NULL UNIQUE," +
                    "password_hash TEXT NOT NULL," +
                    "password_salt TEXT NOT NULL)";
    private static final String CREATE_INVENTORY_TABLE =
            "CREATE TABLE inventory (" +
                    "item_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "item_name TEXT NOT NULL," +
                    "quantity INTEGER NOT NULL DEFAULT 0," +
                    "low_stock_threshold INTEGER NOT NULL DEFAULT 0)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION );

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //------------------- Account Functionality ---------------------//
    public boolean registerUser(String username, String password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        //Returns false if the username already exists
        if (usernameExists(username)){
            return false;
        }

            // Generate a random salt
            byte[] salt = PasswordUtility.generateSalt();

            // Hash the password using the salt
            byte[] hash = PasswordUtility.hashPassword(password, salt);

            // Encode both byte arrays as strings
            String encodedSalt = Base64.encodeToString(salt, Base64.NO_WRAP);
            String encodedHash = Base64.encodeToString(hash, Base64.NO_WRAP);


            ContentValues values = new ContentValues();
            //Stores values for insert
            values.put("username", username);
            values.put("password_hash", encodedHash);
            values.put("password_salt", encodedSalt);

            //Gets the
            SQLiteDatabase db = this.getWritableDatabase();
            //Inserts the user into the database
            long result = db.insert("users", null, values);

        //Returns true if the insertion was successful
        return result != -1;
    }

    public boolean usernameExists(String username){
        SQLiteDatabase db = this.getReadableDatabase();

        //Searches the db for the username
        Cursor cursor = db.query(
                "users",
                new String[]{"user_id"},
                "username = ?",
                new String[]{username},
                null,
                null,
                null
        );

        //Stores cursor value if a record is found
        boolean exists = cursor.getCount() > 0;
        //Closes the cursor
        cursor.close();

        //Returns True if username already exists False otherwise
        return exists;
    }

    public boolean loginUser(String username, String password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        SQLiteDatabase db = this.getReadableDatabase();

        //Searches database for username, password_hash, and password_salt
        Cursor cursor = db.query(
                "users",
                new String[]{"password_hash", "password_salt"},
                "username = ?",
                new String[]{username},
                null,
                null,
                null
        );

        //Checks if found
        if (!cursor.moveToFirst()) {
            return false;
        }

        //Gets the stored password hash
        String encodedHash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
        String encodedSalt = cursor.getString(cursor.getColumnIndexOrThrow("password_salt"));

        //Decode the stored values
        byte[] storedHash = Base64.decode(encodedHash, Base64.NO_WRAP);
        byte[] storedSalt = Base64.decode(encodedSalt, Base64.NO_WRAP);

        //Hashes the entered password with the stored salt
        byte[] calculateHash = PasswordUtility.hashPassword(password, storedSalt);

        //Compares the calculated hash with the stored hash
        return MessageDigest.isEqual(calculateHash, storedHash);

    }

    //------------- Inventory Functionality -------------------//

    //Adds an item to the inventory
    public boolean addItem(String name, int item_quantity, int item_minimum){
        //Input validation
        if (name == null || name.trim().isEmpty()){
            return false;
        }

        if (item_quantity < 0 || item_minimum < 0){
            return false;
        }

        ContentValues values = new ContentValues();

        //Stores values for insertion
        values.put("item_name", name);
        values.put("quantity", item_quantity);
        values.put("low_stock_threshold", item_minimum);

        //Opens writeable database
        SQLiteDatabase db = this.getWritableDatabase();

        //Inserts the item into the inventory table
        long result = db.insert("inventory", null, values);

        return result != -1;
    }

    //Gets the inventory items
    public List<InventoryItem> getAllItems(){
        //TODO: Query all records from the inventory table
        //Creates a list to hold items
        List<InventoryItem> items = new ArrayList<>();

        //Opens a readable database
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the inventory table
        // TODO: Create your Cursor
        try(Cursor cursor = db.query(
                "inventory",
                new String[]{"item_id", "item_name", "quantity", "low_stock_threshold"},
                null,
                null,
                null,
                null,
                "item_name ASC"
        )) {
            //Loops through the database records and stores the values
            while (cursor.moveToNext()){
                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow("item_id"));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                int minimum = cursor.getInt(cursor.getColumnIndexOrThrow("low_stock_threshold"));

                //Creates an InventoryItem
                InventoryItem item = new InventoryItem(itemId, itemName, quantity, minimum);
                //Adds item to items list
                items.add(item);
            }
        }

        return items;
    }

    //Updates existing inventory items
    public boolean updateItems(int itemId, String name, int quantity, int minimum){
        //Input Validation
        if (name == null || name.isEmpty()){
            return false;
        }

        if (quantity < 0 || minimum < 0){
            return false;
        }

        ContentValues values = new ContentValues();

        //Stores values for insertion
        values.put("item_name", name);
        values.put("quantity", quantity);
        values.put("low_stock_threshold", minimum);

        //Opens writeable database
        SQLiteDatabase db = this.getWritableDatabase();

        int updated = db.update(
                "inventory",
                values,
                "item_id = ?",
                new String[]{String.valueOf(itemId)}
        );

        return updated > 0;
    }

    //Deletes an item from the inventory
    public boolean deleteItem(int itemId){
        //Opens the database for writing
        SQLiteDatabase db = this.getWritableDatabase();

        //Deletes the item found with itemID
        int deleted = db.delete(
                "inventory",
                "item_id = ?",
                new String[]{String.valueOf(itemId)}
        );

        //Returns true if a row was deleted
        return deleted > 0;
    }




}
