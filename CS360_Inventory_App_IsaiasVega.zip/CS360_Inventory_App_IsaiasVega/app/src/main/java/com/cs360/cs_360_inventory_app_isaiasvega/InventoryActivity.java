package com.cs360.cs_360_inventory_app_isaiasvega;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewInventory;
    private InventoryAdapter inventoryAdapter;
    private DatabaseHelper dbHelper;
    private SMSHelper smsHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        //Initializes Database helper
        dbHelper = new DatabaseHelper(this);

        //Initializes SMSHelper
        smsHelper = new SMSHelper(this);

        //Connects RecyclerView
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);

        //Sets how items are shown
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));

        //Gets saved items from DB
        List<InventoryItem> items = dbHelper.getAllItems();

        //Creates the adapter with the list
        inventoryAdapter = new InventoryAdapter(
                items,
                new InventoryAdapter.OnItemClickListener() {
            @Override
                    public void onEditClick(InventoryItem item){
                editInventoryItem(item);
            }
            @Override
                    public void onDeleteClick(InventoryItem item){
                deleteInventoryItem(item);
            }
                }
                );

        //Connects RecyclerView to InventoryAdapter
        recyclerViewInventory.setAdapter(inventoryAdapter);

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonAddItem.setOnClickListener(v -> addInventoryItem());

        Button buttonSettings = findViewById(R.id.buttonSettings);

        //Handles settings button
        buttonSettings.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    NotificationActivity.class
            );

            startActivity(intent);
        });
    }

    private void editInventoryItem(InventoryItem item){
        //Creates a LayoutInflater
        LayoutInflater inflater = LayoutInflater.from(this);

        //Converts CML to view
        View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);

        //Gets the editText fields
        EditText itemNameEdit = dialogView.findViewById(R.id.itemNameEdit);
        EditText quantityEdit = dialogView.findViewById(R.id.quantityEdit);
        EditText minimumEdit = dialogView.findViewById(R.id.minimumEdit);

        //Sets the text to match the item
        itemNameEdit.setText(item.getItemName());
        quantityEdit.setText(String.valueOf(item.getQuantity()));
        minimumEdit.setText(String.valueOf(item.getMinimum()));

        new AlertDialog.Builder(this).setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    //Stores the updated values as strings
                    String updatedName = itemNameEdit.getText().toString().trim();
                    String quantityInput = quantityEdit.getText().toString().trim();
                    String minimumInput = minimumEdit.getText().toString().trim();

                    //Validates input
                    if(updatedName.isEmpty() || quantityInput.isEmpty() || minimumInput.isEmpty()){
                        Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //Converts strings to int
                    int updatedQuantity;
                    int updatedMinimum;

                    //Attempts to convert strings to ints
                    try{
                        updatedQuantity = Integer.parseInt(quantityInput);
                        updatedMinimum = Integer.parseInt(minimumInput);
                    }catch (NumberFormatException e){
                        Toast.makeText(this, "Valid numbers only", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //Tries to update the item
                    boolean success = dbHelper.updateItems(item.getItemId(), updatedName, updatedQuantity, updatedMinimum);

                    //On success, display message and refresh inventory
                    if (success){
                        InventoryItem updatedItem = new InventoryItem(item.getItemId(), updatedName, updatedQuantity, updatedMinimum);

                        //Check if the item was low stock
                        boolean wasLowStock = item.isLowStock();

                        //Check if the updated item is now low stock
                        boolean isNowLowStock = updatedItem.isLowStock();

                        if(!wasLowStock && isNowLowStock){
                            smsHelper.sendLowStockAlert(updatedItem);
                        }

                        Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();

                        refreshInventory();
                    }else{
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                }).show();
    }

    private void deleteInventoryItem(InventoryItem item){
        //Creates a dialog box to confirm deletion or cancel
        new AlertDialog.Builder(this).setTitle("Delete Item")
                .setMessage("Do you wish to remove " + item.getItemName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean success = dbHelper.deleteItem(item.getItemId());
            //Checks if deletion was successful or not
            if(success){
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();

                //Refresh the list
                refreshInventory();
            }else{
                Toast.makeText(this, "Deletion failed", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Cancel", (dialog, which) -> {
            dialog.dismiss();
                }).show();
    }

    private void addInventoryItem(){
        //Creates a LayoutInflater
        LayoutInflater inflater = LayoutInflater.from(this);

        //Converts CML to view
        View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);

        //Gets the editText fields
        EditText itemNameEdit = dialogView.findViewById(R.id.itemNameEdit);
        EditText quantityEdit = dialogView.findViewById(R.id.quantityEdit);
        EditText minimumEdit = dialogView.findViewById(R.id.minimumEdit);

        new AlertDialog.Builder(this).setTitle("Add Item").setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    //Stores the updated values as strings
                    String newName = itemNameEdit.getText().toString().trim();
                    String quantityInput = quantityEdit.getText().toString().trim();
                    String minimumInput = minimumEdit.getText().toString().trim();

                    //Validates input
                    if(newName.isEmpty() || quantityInput.isEmpty() || minimumInput.isEmpty()){
                        Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //Converts strings to int
                    int newQuantity;
                    int newMinimum;

                    //Attempts to convert strings to ints
                    try{
                        newQuantity = Integer.parseInt(quantityInput);
                        newMinimum = Integer.parseInt(minimumInput);
                    }catch (NumberFormatException e){
                        Toast.makeText(this, "Valid numbers only", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //Validates input
                    if(newQuantity < 0 || newMinimum < 0){
                        Toast.makeText(this, "Values cannot be negative", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //Tries to update the item
                    boolean success = dbHelper.addItem(newName, newQuantity, newMinimum);

                    //On success, display message and refresh inventory
                    if (success){
                        //Creates a new item for the SMS alert
                        InventoryItem newItem = new InventoryItem(0, newName, newQuantity, newMinimum);
                        smsHelper.sendLowStockAlert(newItem);

                        Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();

                        refreshInventory();
                    }else{
                        Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                }).show();
    }

    //Refreshes the inventory
    private void refreshInventory(){
        List<InventoryItem> updatedItems = dbHelper.getAllItems();
        inventoryAdapter.updateItems(updatedItems);
    }


}