package com.cs360.cs_360_inventory_app_isaiasvega;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.materialswitch.MaterialSwitch;


//Handles phone number, switches, permission requests, and saved notification preferences
public class NotificationActivity extends AppCompatActivity {
    //UI components
    private MaterialSwitch switchSMS;
    private EditText editTextPhone;
    private ToggleButton toggleNotifications;
    private Button buttonBackToInventory;

    //Handles the SMS permission response
    private ActivityResultLauncher<String> smsPermissionLauncher;

    //Stores the SMS permission response
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        //Initializes UI
        editTextPhone = findViewById(R.id.editTextPhone);
        buttonBackToInventory = findViewById(R.id.buttonBackToInventory);
        toggleNotifications = findViewById(R.id.toggleNotifications);
        switchSMS = findViewById(R.id.switchSMS);

        //Preferences for SMS
        preferences = getSharedPreferences("NotificationSettings", MODE_PRIVATE);

        //Registers permission request handler
        smsPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted){
                        //Saves the SMS permission as enabled
                        saveSMSPreference(true);
                        switchSMS.setChecked(true);

                        Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                    }else{
                        //Saves the SMS permission as disabled
                        saveSMSPreference(false);
                        switchSMS.setChecked(false);

                        Toast.makeText(this, "SMS permission denied. To enable please do so in your device settings.", Toast.LENGTH_SHORT).show();
                    }
                });

        //Loads saved settings
        loadPreferences();

        //Handles SMS switch
        switchSMS.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked){
                //User wants to enable SMS
                checkSMSPermission();
            }else{
                //User disabled SMS notifications
                saveSMSPreference(false);
            }
        });

        //Handle notification toggle button
        toggleNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferences.edit().putBoolean("notifications_enabled", isChecked).apply();
                }
        );


        //Saves phone number if no longer focused on field
        editTextPhone.setOnFocusChangeListener((v, hasFocus) -> {
            if(!hasFocus){
                savePhoneNumber();
            }
        });

        //Navigates back to inventory page
        buttonBackToInventory.setOnClickListener(v -> {
            savePhoneNumber();
            finish();
        });

    }

    private void checkSMSPermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
            //Permission already granted
            saveSMSPreference(true);
        }else{
            //Request permission from the user
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    //Saves whether SMS is enabled or not
    private void saveSMSPreference(boolean enabled){
        preferences.edit().putBoolean("sms_enabled", enabled).apply();
    }

    //Saves the phone number
    private void savePhoneNumber(){
        String phoneNumber = editTextPhone.getText().toString().trim();

        preferences.edit().putString("sms_phone", phoneNumber).apply();
    }

    //Loads saved preferences
    private void loadPreferences(){
        //Gets SMS preference
        boolean smsEnabled = preferences.getBoolean("sms_enabled", false);

        //Gets Notification preference
        boolean notificationsEnabled = preferences.getBoolean("notifications_enabled", false);

        //Gets saved phone number
        String phoneNumber = preferences.getString("sms_phone", "");

        //Checks for phone permissions
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        switchSMS.setChecked(smsEnabled && hasPermission);
        toggleNotifications.setChecked(notificationsEnabled);
        editTextPhone.setText(phoneNumber);

        //If permission was revoked, updates preference
        if(smsEnabled && !hasPermission){
            saveSMSPreference(false);
        }

    }

    @Override
    protected void onPause(){
        savePhoneNumber();
        super.onPause();
    }

}
