package com.cs360.cs_360_inventory_app_isaiasvega;

import android.Manifest;
import android.content.pm.PackageManager;

import android.content.Context;
import android.content.SharedPreferences;

import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import android.util.Log;

//Handles checking if SMS can be sent and sending the alerts
public class SMSHelper{

    private final Context context;
    private final SharedPreferences preferences;

    public SMSHelper(Context context){
        this.context = context.getApplicationContext();
        this.preferences = this.context.getSharedPreferences("NotificationSettings", Context.MODE_PRIVATE);
    }

    //Checks if SEND_SMS permission is granted
    public boolean hasSMSPermission(){
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    //Checks if SMS notifications are enabled
    public boolean isSMSEnabled(){
        //Gets SMS preference
        boolean smsEnabled = preferences.getBoolean("sms_enabled", false);

        //Gets Notification preference
        boolean notificationsEnabled = preferences.getBoolean("notifications_enabled", false);

        //Gets saved phone number
        String phoneNumber = preferences.getString("sms_phone", "");

        return smsEnabled && notificationsEnabled && !phoneNumber.trim().isEmpty() && hasSMSPermission();

    }

    public String getPhoneNumber(){
        return preferences.getString("sms_phone", "").trim();
    }

    //Sends SMS if item is low_stock
    public boolean sendLowStockAlert(InventoryItem item){
        //Checks if SMS and Notifs are enabled
        boolean canSend = isSMSEnabled() && hasSMSPermission();

        //Checks if SMS and notifications are enabled
        if(!canSend){
            return false;
        }
        //Checks if an item is low stock
        if(!item.isLowStock()) {
            return false;
        }

        String phoneNumber = getPhoneNumber();

        if(!isValidPhoneNumber(phoneNumber)){
            return false;
        }

        //SMS message to be sent
        String smsMessage = "Low Stock Alert: " + item.getItemName() + " has " + item.getQuantity() + " remaining. Minimum quantity: " + item.getMinimum() + ".";

        //Tries to send the SMS, if failed returns an error
        try{
            //Initializes SMS manager
            SmsManager smsManager = context.getSystemService(SmsManager.class);

            if (smsManager == null){
                return false;
            }

            //Sends the SMS message
            smsManager.sendTextMessage(phoneNumber, null, smsMessage, null, null);

            return true;
        }catch(SecurityException | IllegalArgumentException | UnsupportedOperationException e){
            Log.e("SMSHelper", "Failed to initiate SMS", e);
            return false;
        }
    }

    //Checks that the phone number is valid
    public boolean isValidPhoneNumber(String phoneNumber){
        if(phoneNumber == null){
            return false;
        }

        //For testing with emulator
        if(phoneNumber.matches("555[4-9]")){
            return true;
        }

        //Cleans up the phone number
        String cleanedNumber = phoneNumber.replaceAll("[^0-9]", "");

        if (cleanedNumber.length() != 10){
            return false;
        }

        //Removes country code
        if (cleanedNumber.length() == 11 && cleanedNumber.startsWith("1")){
            cleanedNumber = cleanedNumber.substring(1);
        }

        return cleanedNumber.length() == 10;
    }

}
