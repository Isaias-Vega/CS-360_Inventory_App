package com.cs360.cs_360_inventory_app_isaiasvega;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Open or create the database
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Close the database when finished testing
        //db.close();

        //Connects UI elements to their ID
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editTextTextPassword);

        //Finds the login and create account button
        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);

        //Handle Login Button
        loginButton.setOnClickListener(v -> {
            try {
                loginUser();
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                throw new RuntimeException(e);
            }
        });

        //Handle Create Account Button
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    CreateAccountActivity.class
            );
            startActivity(intent);
        });
    }

    private void loginUser() throws NoSuchAlgorithmException, InvalidKeySpecException {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        //Checks if the fields are empty
        if (username.isEmpty()){
            editUsername.setError("Please enter your username.");
            return;
        }
        if (password.isEmpty()){
            editPassword.setError("Please enter your password.");
            return;
        }

        //Starting a background thread for log in
        ExecutorService executor = Executors.newSingleThreadExecutor();

        executor.execute(() -> {
            try {
                DatabaseHelper dbHelper = new DatabaseHelper(getApplicationContext());

                boolean success = dbHelper.loginUser(username, password);

                //Return to the main thread to update the ui
                runOnUiThread(() -> {
                    if(success){
                        //Opens the inventory page
                        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);

                        startActivity(intent);
                        finish();
                    }else{
                        Toast.makeText(MainActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                Log.e("LoginActivity", "Authentication error", e);

                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Error during log in.", Toast.LENGTH_SHORT).show();
                });
            }
        });

        executor.shutdown();
    }

}